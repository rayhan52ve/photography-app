

<?php $__env->startSection('content'); ?>
    <main class="mdl-layout__content">
        <div class="mdl-grid ui-cards">

            <div class="mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone">
                <div class="d-flex justify-content-between align-items-center p-3">
                    <h3 style="display: inline-block; margin-right: 10px;">Album: <?php echo e($album->name); ?></h3>
                    <a class="btn btn-outline-info" href="<?php echo e(route('admin.photography.create')); ?>">Create Album</a>
                </div>
            </div>

            <div class="container">
                <div class="m-4">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $album->photographies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photography): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-3 mb-4 position-relative">
                                <div class="card bg-dark text-white">
                                    <img src="<?php echo e(asset('uploads/photography/' . $photography->photo)); ?>" style="height: 200px"
                                        class="card-img" alt="">
                                    <div class="card-img-overlay d-flex flex-column justify-content-between">
                                        <div class="position-absolute top-0 end-0 badge bg-success"><?php echo e($key + 1); ?>

                                        </div>
                                        <div>
                                            <a href="<?php echo e(route('admin.album.edit', $album->id)); ?>" class="btn btn-warning"
                                                title="Edit">
                                                <box-icon name='edit'></box-icon>
                                            </a>
                                            <form id="<?php echo e('form_' . $photography->id); ?>"
                                                action="<?php echo e(route('admin.photography.destroy', $photography)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button data-id="<?php echo e($photography->id); ?>" title="Delete"
                                                    class="delete btn btn-rounded btn-danger ml-1 mt-1" type="button">
                                                    <box-icon name='trash'></box-icon>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone">
                                <h3 class="text-center text-danger">This album has no photo Yet</h3>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>




        </div>
    </main>

    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session()->has('msg')): ?>
                Swal.fire({
                    position: 'top-end',
                    icon: '<?php echo e(session('cls')); ?>',
                    toast: 'true',
                    title: '<?php echo e(session('msg')); ?>',
                    showConfirmButton: false,
                    confirmButtonText: "ok",
                    timerProgressBar: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showCloseButton: true,
                    timer: 3000
                })
            <?php endif; ?>


            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')

                Swal.fire({
                    title: 'Are you sure to delete this?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()

                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Backend/modules/album/show.blade.php ENDPATH**/ ?>