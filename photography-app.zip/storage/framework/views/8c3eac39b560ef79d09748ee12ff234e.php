

<?php $__env->startSection('content'); ?>
    <main class="mdl-layout__content mdl-color--grey-100">
        <div class="mdl-card mdl-shadow--2dp employer-form" action="#">
            <div class="mdl-card__title">
                <h2>Create Album Category</h2>
            </div>

            <div class="mdl-card__supporting-text">
                <form action="<?php echo e(route('admin.category.update',$category->id)); ?>" method="post" class="form">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form__article">
                        <div class="mdl-grid">
                            <div
                                class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                <input class="mdl-textfield__input" type="text" id="firstName" name="name" value="<?php echo e($category->name); ?>" required />
                                <label class="mdl-textfield__label" for="firstName">Album Category Title</label>
                            </div>
                        </div>
                    </div>

                    <div class="form__action">
                        <button id="submit_button" type="submit"
                            class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php $__env->startPush('js'); ?>
        <?php if(session()->has('msg')): ?>
            <script>
                Swal.fire({
                    position: 'top-end',
                    icon: '<?php echo e(session('cls')); ?>',
                    toast: 'true',
                    title: '<?php echo e(session('msg')); ?>',
                    showConfirmButton: false,
                    confirmButtonText: "ok",
                    timerProgressBar: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showCloseButton: true,
                    timer: 3000
                })
            </script>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Backend/modules/category/edit.blade.php ENDPATH**/ ?>