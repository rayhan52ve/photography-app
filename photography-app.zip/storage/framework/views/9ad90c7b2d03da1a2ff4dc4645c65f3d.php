

<?php $__env->startSection('content'); ?>
    <!-- ======= Carousel Section ======= -->
    <div class="home-slider owl-carousel js-fullheight">
        <?php $__empty_1 = true; $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="slider-item js-fullheight"
                style="background-image:url('<?php echo e(asset('uploads/hero/' . $hero->photo)); ?>');">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                        <div class="col-md-12 ftco-animate">
                            <div class="text w-100 text-center">
                                <h2><?php echo e($hero->sub_title); ?></h2>
                                <h1 class="mb-3"><?php echo e($hero->title); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="slider-item js-fullheight"
                style="background-image:url('<?php echo e(asset('frontend/carousel/images/slider-1.jpg')); ?>');">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                        <div class="col-md-12 ftco-animate">
                            <div class="text w-100 text-center">
                                <h2>Best Place to Travel</h2>
                                <h1 class="mb-3">Norway</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="slider-item js-fullheight"
                style="background-image:url('<?php echo e(asset('frontend/carousel/images/slider-2.jpg')); ?>');">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                        <div class="col-md-12 ftco-animate">
                            <div class="text w-100 text-center">
                                <h2>Best Place to Travel</h2>
                                <h1 class="mb-3">Japan</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="slider-item js-fullheight"
                style="background-image:url('<?php echo e(asset('frontend/carousel/images/slider-3.jpg')); ?>');">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                        <div class="col-md-12 ftco-animate">
                            <div class="text w-100 text-center">
                                <h2>Best Place to Travel</h2>
                                <h1 class="mb-3">Singapore</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/modules/index.blade.php ENDPATH**/ ?>