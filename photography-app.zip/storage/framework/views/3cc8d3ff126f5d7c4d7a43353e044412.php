

<?php $__env->startSection('content'); ?>
    <main class="mdl-layout__content mdl-color--grey-100">
        <div class="container">
            <div class="row justify-content-center m-5">
                <div class="col-md-4">
                    <div class="card shadow">
                        <div class="card-header">
                            <h2>Create Album Category</h2>
                            <?php if($categories->count() < 1): ?>
                                <div class="text-danger">Please create an album category before creating album.</div>
                            <?php endif; ?>
                        </div>
    
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.category.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Album Category Title</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
    
                                <button type="submit" class="btn btn-info mt-2">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
    
                <div class="col-md-6"> <!-- Added missing class -->
                    <div class="card shadow">
                        <div class="card-header">
                            <h1 class="card-title">Category List</h1>
                        </div>
                        <div class="card-body p-0">
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Categories</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>"
                                                    class="btn btn-warning" title="Edit">
                                                    <box-icon name='edit'></box-icon>
                                                </a>
                                                <form id="<?php echo e('form_' . $category->id); ?>"
                                                    action="<?php echo e(route('admin.category.destroy', $category)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button data-id="<?php echo e($category->id); ?>" title="Delete"
                                                        class="delete btn btn-danger ml-1 mt-1" type="button">
                                                        <box-icon name='trash'></box-icon>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-center">No data found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session()->has('msg')): ?>
                Swal.fire({
                    position: 'top-end',
                    icon: '<?php echo e(session('cls')); ?>',
                    toast: 'true',
                    title: '<?php echo e(session('msg')); ?>',
                    showConfirmButton: false,
                    confirmButtonText: "ok",
                    timerProgressBar: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showCloseButton: true,
                    timer: 3000
                })
            <?php endif; ?>


            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')

                Swal.fire({
                    title: 'Are you sure to delete this category?',
                    text: "All the albums and photos related to this calegory may be lost!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()

                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Backend/modules/category/index.blade.php ENDPATH**/ ?>