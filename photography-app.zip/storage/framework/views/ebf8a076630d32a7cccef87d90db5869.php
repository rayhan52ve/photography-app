

<?php $__env->startSection('content'); ?>
    <main class="mdl-layout__content ui-form-components">

        <div class="mdl-grid mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone mdl-cell--top">

            <div class="mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone">
                <div class="mdl-card mdl-shadow--2dp">
                    <div class="mdl-card__title">
                        <h5 class="mdl-card__title-text text-color--white">Bio Info</h5>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <form method="post" action="<?php echo e(route('admin.bio.store')); ?>" enctype="multipart/form-data"
                            class="form form--basic">
                            <?php echo csrf_field(); ?>
                            <div class="mdl-grid">
                                <div
                                    class="mdl-cell mdl-cell--4-col-desktop mdl-cell--4-col-tablet mdl-cell--4-col-phone form__article">
                                    <h3 class="text-color--smooth-gray">Biopic</h3>
                                    <label class="image" for="imageInput">
                                        <input type="file" id="imageInput" value="<?php echo e(old('image')); ?>" name="image"
                                            class="form-control">
                                        <?php if(@$bio->image): ?>
                                            <img id="profileImage" src="<?php echo e(asset('uploads/bio/' . $bio->image)); ?>"
                                                height="100%" width="300px" class="rounded-top">
                                        <?php else: ?>
                                            <img id="profileImage" src="<?php echo e(asset('asset/bio.jpg')); ?>" height="100%"
                                                width="300px" class="rounded-top">
                                        <?php endif; ?>
                                    </label>

                                </div>
                                <div
                                    class="mdl-cell mdl-cell--8-col-desktop mdl-cell--8-col-tablet mdl-cell--4-col-phone form__article">
                                    <h3 class="text-color--smooth-gray text-success">BIO INPUT FIELDS</h3>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="name" class="mdl-textfield__input" type="text"
                                                    value="<?php echo e(@$bio->name); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label" for="floating-first-name">
                                                    Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="age" class="mdl-textfield__input" type="text"
                                                    value="<?php echo e(@$bio->age); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label" for="floating-first-name">Age</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="designation" class="mdl-textfield__input" type="text"
                                                    value="<?php echo e(@$bio->designation); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label"
                                                    for="floating-first-name">Designation</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="phone" class="mdl-textfield__input" type="number"
                                                    value="<?php echo e(@$bio->phone); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label" for="floating-first-name">Phone</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="email" class="mdl-textfield__input" type="email"
                                                    value="<?php echo e(@$bio->email); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label" for="floating-first-name">Email</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="city" class="mdl-textfield__input" type="text"
                                                    value="<?php echo e(@$bio->city); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label" for="floating-first-name">Address</label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <input name="description" class="mdl-textfield__input" type="text"
                                                    value="<?php echo e(@$bio->description); ?>" id="floating-first-name">
                                                <label class="mdl-textfield__label"
                                                    for="floating-first-name">Description</label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div
                                                class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label full-size">
                                                <textarea class="mdl-textfield__input" id="floating-first-name" name="story" id="" rows="5"><?php echo e(@$bio->story); ?></textarea>
                                                <label class="mdl-textfield__label" for="floating-first-name">Your
                                                    Story</label>
                                            </div>
                                        </div>

                                        <button type="submit"
                                            class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect button--colored-teal">
                                            SAVE
                                        </button>

                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </main>

    <?php $__env->startPush('css'); ?>
        <style>
            .image {
                display: block;
                width: 500px;
                max-width: 100%;
                background-color: rgb(239, 241, 245);
                border-radius: 5px;
                font-size: 1em;
                line-height: 2em;
                text-align: center;
            }

            .image:hover {
                background-color: rgb(207, 226, 207);
            }

            .image:active {
                background-color: skyblue;
            }

            #imageInput {
                border: 5px;
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('js'); ?>
        <script>
            var imageInput = document.getElementById("imageInput");
            var profileImage = document.getElementById("profileImage");

            imageInput.addEventListener("change", function() {
                // Check if a file has been selected
                if (imageInput.files && imageInput.files[0]) {
                    var reader = new FileReader();

                    // When the file is loaded, set the src attribute of the img element
                    reader.onload = function(e) {
                        profileImage.src = e.target.result;
                    };

                    // Read the selected file as a data URL
                    reader.readAsDataURL(imageInput.files[0]);
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
    <?php if(session()->has('msg')): ?>
        <?php $__env->startPush('js'); ?>
            <script>
                Swal.fire({
                    position: 'top-right',
                    icon: '<?php echo e(session('cls')); ?>',
                    toast: 'true',
                    title: '<?php echo e(session('msg')); ?>',
                    showConfirmButton: false,
                    confirmButtonText: "ok",
                    timerProgressBar: false,
                    showCancelButton: false,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showCloseButton: true,
                    timer: 2000
                })
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Backend/modules/bio.blade.php ENDPATH**/ ?>