

<?php $__env->startSection('content'); ?>
    <!-- ======= End Page Header ======= -->
    <div class="page-header d-flex align-items-center">
        <div class="container position-relative">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                    <h2>Bio</h2>
                    <p><?php echo e(@$bio->description); ?></p>

                    

                </div>
            </div>
        </div>
    </div><!-- End Page Header -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">

            <div class="row gy-4 justify-content-center">
                <div class="col-lg-4">
                    <img src="<?php echo e(asset('uploads/bio/' . $bio->image)); ?>" class="img-fluid" alt="">
                </div>
                <div class="col-lg-5 content">
                    <h2>Professional Photographer from New York</h2>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul>
                                <li><i class="bi bi-chevron-right"></i> <strong>Name:</strong>
                                    <span><?php echo e(@$bio->name); ?></span></li>
                                <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong>
                                    <span><?php echo e(@$bio->phone); ?></span></li>
                                <li><i class="bi bi-chevron-right"></i> <strong>City:</strong>
                                    <span><?php echo e(@$bio->city); ?></span></li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <ul>
                                <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong>
                                    <span><?php echo e(@$bio->age); ?></span></li>
                                <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong>
                                    <span><?php echo e(@$bio->email); ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <p class="py-3">
                      <?php echo e(@$bio->story); ?>

                    </p>
                </div>
            </div>

        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/modules/about.blade.php ENDPATH**/ ?>