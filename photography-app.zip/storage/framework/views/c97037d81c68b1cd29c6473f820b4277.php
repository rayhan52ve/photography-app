<?php $__env->startSection('content'); ?>
    <main class="mdl-layout__content">
        <div class="mdl-grid mdl-grid--no-spacing dashboard">
            <div class="container my-4">
                <div class="row justify-content-center">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title">Edit Website info</h2>
                                <hr>
                                <form class="form-horizontal form-material mx-2" action="<?php echo e(route('admin.web-info.store')); ?>"
                                    method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="row mb-3">
                                            <div class="col-md-2">
                                                <div class="mb-4">
                                                    <label class="image" for="imageInput1"
                                                        style="border: 2px solid #ccc; padding: 5px; display: inline-block;">
                                                        <input type="file" id="imageInput1" name="logo"
                                                            class="form-control">
                                                        <img id="profileImage1"
                                                            src="/uploads/websiteinfo/logo/<?php echo e(@$websiteInfo->logo); ?>"
                                                            height="150px" width="150px">

                                                        <i class="mdi mdi-camera mdi-24px"></i> Website Logo
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-2 mx-5">
                                                <div class="mb-4">
                                                    <label class="image" for="imageInput2"
                                                        style="border: 2px solid #ccc; padding: 5px; display: inline-block;">
                                                        <input type="file" id="imageInput2" name="fevicon"
                                                            class="form-control">
                                                        <img id="profileImage2"
                                                            src="/uploads/websiteinfo/fevicon/<?php echo e(@$websiteInfo->fevicon); ?>"
                                                            height="150px" width="150px">
                                                        <i class="mdi mdi-camera mdi-24px"></i> Fevicon
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="address">Website Name</label>
                                                        <input type="text" name="title"
                                                            class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->title); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <h4>Social Media</h4>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="facebook">Facebook</label>
                                                        <input type="text" name="facebook"
                                                            class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->facebook); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="tweeter">Tweeter</label>
                                                        <input type="text" name="tweeter"
                                                            class="form-control <?php $__errorArgs = ['tweeter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->tweeter); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['tweeter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="instagram">Instagram</label>
                                                        <input type="text" name="instagram"
                                                            class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->instagram); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="linkedin">Linkedin</label>
                                                        <input type="text" name="linkedin"
                                                            class="form-control <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->linkedin); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <h4>Footer</h4>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="copyright">Copy Right</label>
                                                        <input type="text" name="copyright"
                                                            class="form-control <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            value="<?php echo e(@$websiteInfo->copyright); ?>" />
                                                    </div>
                                                    <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 d-flex">
                                                <button type="submit"
                                                    class="btn btn-success mx-auto mx-md-0 text-white">Update
                                                    Website
                                                    info</button>
                                            </div>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <?php $__env->startPush('css'); ?>
        <style>
            .image {
                display: block;
                width: 150px;
                height: auto;
                background-color: rgb(239, 241, 245);
                border-radius: 5px;
                font-size: 1em;
                line-height: 2em;
                text-align: center;
            }

            .image:hover {
                background-color: rgb(207, 226, 207);
            }

            .image:active {
                background-color: skyblue;
            }

            #imageInput1 {
                border: 5px;
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
            }

            #imageInput2 {
                border: 5px;
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
            }

            #imageInput3 {
                border: 5px;
                clip: rect(1px, 1px, 1px, 1px);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
            }
        </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('js'); ?>
        <script>
            // first image
            var imageInput1 = document.getElementById("imageInput1");
            var profileImage1 = document.getElementById("profileImage1");

            imageInput1.addEventListener("change", function() {
                if (imageInput1.files && imageInput1.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        profileImage1.src = e.target.result;
                    };

                    reader.readAsDataURL(imageInput1.files[0]);
                }
            });

            // second image
            var imageInput2 = document.getElementById("imageInput2");
            var profileImage2 = document.getElementById("profileImage2");

            imageInput2.addEventListener("change", function() {
                if (imageInput2.files && imageInput2.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        profileImage2.src = e.target.result;
                    };

                    reader.readAsDataURL(imageInput2.files[0]);
                }
            });

            // third image
            var imageInput3 = document.getElementById("imageInput3");
            var profileImage3 = document.getElementById("profileImage3");

            imageInput3.addEventListener("change", function() {
                if (imageInput3.files && imageInput3.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        profileImage3.src = e.target.result;
                    };

                    reader.readAsDataURL(imageInput3.files[0]);
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script>
            <?php if(session()->has('msg')): ?>
                Swal.fire({
                    position: 'top-end',
                    icon: '<?php echo e(session('cls')); ?>',
                    toast: 'true',
                    title: '<?php echo e(session('msg')); ?>',
                    showConfirmButton: false,
                    timer: 3000
                })
            <?php endif; ?>


            $('.delete').on('click', function() {
                let id = $(this).attr('data-id')

                Swal.fire({
                    title: 'আপনি কি নিশ্চিত?',
                    text: "ডিলিট করার পর ডাটা আর ফেরতযোগ্য নয়!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(`#form_${id}`).submit()

                    }
                })
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Backend/modules/website_info.blade.php ENDPATH**/ ?>