    <!-- ======= Header ======= -->
    <header id="header" class="header d-flex align-items-center fixed-top">
        <div class="container-fluid d-flex align-items-center justify-content-between">

            <a href="index.html" class="logo d-flex align-items-center  me-auto me-lg-0">
                <!-- Uncomment the line below if you also wish to use an image logo -->
                <img src="/uploads/websiteinfo/logo/<?php echo e(@$websiteInfo->logo); ?>" alt="">
                <h1><?php echo e(@$websiteInfo->title); ?></h1>
                <i class="bi bi-camera mx-2"></i>

            </a>

            <nav id="navbar" class="navbar">
                <ul>
                    <li><a href="<?php echo e(route('front.home')); ?>"
                            class="<?php echo e(url()->current() == route('front.home') ? 'active' : ''); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('front.about')); ?>"
                            class="<?php echo e(url()->current() == route('front.about') ? 'active' : ''); ?>">Bio</a></li>
                    <li><a href="<?php echo e(route('front.gallery')); ?>"
                            class="<?php echo e(url()->current() == route('front.gallery') ? 'active' : ''); ?>">Gallery</a></li>
                    
                    <li><a href="<?php echo e(route('front.contact')); ?>"
                            class="<?php echo e(url()->current() == route('front.contact') ? 'active' : ''); ?>">Contact</a></li>
                </ul>
            </nav><!-- .navbar -->

            <div class="header-social-links">
                <a href="<?php echo e(@$websiteInfo->tweeter); ?>" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="<?php echo e(@$websiteInfo->facebook); ?>" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="<?php echo e(@$websiteInfo->instagram); ?>" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="<?php echo e(@$websiteInfo->linkedin); ?>" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
            </div>
            <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
            <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

        </div>
    </header><!-- End Header -->
<?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/layouts/includes/topnav.blade.php ENDPATH**/ ?>