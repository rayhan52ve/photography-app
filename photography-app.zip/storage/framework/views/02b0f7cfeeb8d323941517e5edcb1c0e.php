    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="container">
            <div class="copyright">
                &copy; <?php echo e(@$websiteInfo->copyright); ?>

            </div>
            
        </div>
    </footer><!-- End Footer -->
<?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/layouts/includes/footer.blade.php ENDPATH**/ ?>