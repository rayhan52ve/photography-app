

<?php $__env->startSection('content'); ?>
    <!-- ======= End Page Header ======= -->
    <div class="page-header d-flex align-items-center">
        <div class="container position-relative">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                    <h2>16 Albums</h2>
                </div>
            </div>
        </div>
    </div><!-- End Page Header -->

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
        <div class="container">
            <div class="col-md-12">
                <div class="row gy-5 justify-content-start">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3><?php echo e($cat->name); ?></h3>
                        <?php $__currentLoopData = $cat->albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 mb-5">
                                <a href="<?php echo e(route('front.gallerySingle',$album->id)); ?>">
                                    <div class="gallery-item">
                                        <img src="<?php echo e(asset('uploads/album/' . $album->photo)); ?>"
                                            class="img-fluid" alt="" width="300px" style="height:150px">
                                        <p class="pt-2"><?php echo e($album->name); ?></p>
                                    </div>
                                </a>
                            </div><!-- End Gallery Item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>

        </div>
    </section><!-- End Gallery Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/modules/gallery.blade.php ENDPATH**/ ?>