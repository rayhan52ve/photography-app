  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
      href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap"
      rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('frontend/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">

  
  <link rel="stylesheet" href="<?php echo e(asset('frontend/carousel/css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('frontend/carousel/css/owl.theme.default.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/4.5.6/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo e(asset('frontend/carousel/css/style.css')); ?>">
  

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('frontend/assets/css/main.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH C:\laragon\www\photography-app\resources\views/Frontend/layouts/includes/css.blade.php ENDPATH**/ ?>