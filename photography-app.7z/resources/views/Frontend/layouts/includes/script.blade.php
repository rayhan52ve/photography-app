    <!-- Vendor JS Files -->
    <script src="{{ asset('frontend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/vendor/aos/aos.js') }}"></script>
    <script src="{{ asset('frontend/assets/vendor/php-email-form/validate.js') }}"></script>

    <!-- Template Main JS File -->
    <script src="{{ asset('frontend/assets/js/main.js') }}"></script>

    {{-- slide carousel --}}
    <script src="{{asset('frontend/carousel/js/jquery.min.js')}}"></script>
    <script src="{{asset('frontend/carousel/js/popper.js')}}"></script>
    <script src="{{asset('frontend/carousel/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('frontend/carousel/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('frontend/carousel/js/main.js')}}"></script>
    {{-- slide carousel --}}
